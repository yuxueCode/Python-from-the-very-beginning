import pay

pay.alipay.tools.pay()