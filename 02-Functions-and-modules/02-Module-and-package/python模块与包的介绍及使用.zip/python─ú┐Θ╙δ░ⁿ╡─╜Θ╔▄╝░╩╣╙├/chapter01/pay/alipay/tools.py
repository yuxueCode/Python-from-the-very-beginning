

def pay():
    """ 支付宝 支付 """
    print('alipay')


def get_status():
    """ 查询支付状态 """
    print('search pay status')