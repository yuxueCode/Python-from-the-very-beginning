
def pay():
    """ 微信支付 """
    print('wechat pay')