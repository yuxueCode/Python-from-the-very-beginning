from pay.alipay.tools import *


def funct():
    pay()
    get_status()

if __name__ == '__main__':
    funct()