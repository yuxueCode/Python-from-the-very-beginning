import hello

hello.func()