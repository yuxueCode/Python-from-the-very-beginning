## 文件类型常量
FILE_TYPE_UNKNOWN = 10      # 未知文件类型
FILE_TYPE_IMG = 11          # 图片类型的文件
FILE_TYPE_DOC = 12          # word文档
FILE_TYPE_EXCEL = 13        # excel文档
FILE_TYPE_PPT = 14          # ppt文档
