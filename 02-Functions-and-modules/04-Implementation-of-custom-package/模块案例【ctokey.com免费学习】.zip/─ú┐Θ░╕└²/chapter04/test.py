import hello

hello.func()
